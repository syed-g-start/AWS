**Subject: Request for Setup of Amazon FSx for Windows File Server**

**Hello DevOps Team,**

I hope you’re doing well.

I would like to request the setup of an Amazon FSx for Windows File Server with the following specifications:

- **Name:** Amazon FSx for Windows File Server
- **Deployment Type:** Multi-AZ
- **Storage Type:** SSD
- **Storage Size:** 500GB

Please let me know if there are any additional details required or steps I need to follow.

Thank you for your assistance.

Best regards,  
Vinod Kumar
