**Subject**: Request to Add EBS Volume to Prod Windows Server

**Hello DevOps Team,**

I hope you’re doing well.

I would like to request the addition of an EBS volume to our Windows Server instance. Below are the details:

- **Windows Server Name:** wp-db-server
- **EBS Volume Size:** 100GB
- **Mount Point:** Add to D Drive

Please let me know if you need any additional information or if there are any specific procedures I should follow.

Thank you for your assistance.

Best regards,  
Ganta Suresh Babu
