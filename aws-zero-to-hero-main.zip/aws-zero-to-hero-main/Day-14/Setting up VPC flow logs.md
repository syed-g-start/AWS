# Setting up AWS VPC Flow Logs
![Lab -Setting up VPC flow logs in telugu - Moole Muralidhara Reddy - Tech World with Murali](https://github.com/techworldwithmurali/aws-zero-to-hero/blob/main/Day-14/images/Day%2014-Setting%20up%20VPC%20flow%20logs%20-%20Moole%20Muralidhara%20Reddy%20-%20Tech%20World%20with%20Murali.png)

**Note:** You should have already created the S3 bucket for storing the VPC logs.<br>
**Name: murali-vpc-flow-logs**

### Step 1: Sign in to the AWS Management Console:
### Step 2: Open the Amazon VPC Console
### Step 3: Select Your VPC
### Step 4: Create Flow Log
### Step 5: Select the Flow Log Destination as S3
### Step 6: Choose Log Format and Settings
### Step 7: Review Settings
### Step 8: Create the Flow Log
### Step 9: Wait for the Flow Log to be Created:
### Step 10: Verify Flow Logs

#### Congratulations! You have successfully set up and tested the AWS VPC Flow logs.
