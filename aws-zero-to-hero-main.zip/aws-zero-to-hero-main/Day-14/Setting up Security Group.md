# Setting up Security Group
![Lab - Setting up Security Group in telugu - Moole Muralidhara Reddy - Telugu Devops Guru](https://github.com/telugudevopsguru/AWS-Networking-5-Days-Practical-Live-Workshop/blob/46f458603b85d8346bf337c88f6dc6dadac59d1e/Day%201-%20%20AWS%20VPC%20Overview/Images/Lab%20-%20Setting%20up%20Security%20Group%20in%20telugu%20-%20Moole%20Muralidhara%20Reddy%20-%20Telugu%20Devops%20Guru.png)

#### Step 1: Create the Security Group
```xml
Name: Jenkins-Sg
```
#### Step 2: Add the Inbound rules
#### Step 3: Attach the Security Group to the EC2 instance and test them.
####  Congratulations! You have successfully set up and tested the AWS Security Group.
