# Setting up AWS NACL

![Lab - Setting up NACL in telugu - Moole Muralidhara Reddy - Tech Wolrd With Murali](https://github.com/techworldwithmurali/aws-zero-to-hero/blob/main/Day-14/images/Day%2014%20-%20Lab%20-%20Setting%20up%20NACL%20-%20Moole%20Muralidhara%20Reddy%20-%20Tech%20World%20with%20Murali.png)

## Step 1: Create the Public NACL
```xml
Name: Public-NACL
```
## Step 2: Attach the Public Subnets to the Public NACL
## Step 3: Add the Inbound rules and test them
####  Congratulations! You have successfully set up and tested the AWS NACL.
